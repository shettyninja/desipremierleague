# Paddle — player auctions, hosted free on Vercel

Create a tournament, post players with a base price, and let friends bid in real
time. Last bid wins; no bids before the timer = unsold. A bid in the final 5
minutes pushes the close out by 5 more minutes (anti-snipe). Every group keeps a
history, and every player keeps its full bid history.

When deployed, friends join from their own phones with a link like:

    https://your-app.vercel.app/?join=ABC123

---

## What's inside

- **Next.js** app (the UI) + serverless **API routes** (the rules, enforced server-side)
- **Upstash Redis** for shared storage — free, added in two clicks from Vercel
- No login. Anyone with the link/ID (and password, if set) can join and bid.

```
app/                     the screens + API routes
  api/groups/...         create / search / join / post player / bid
  page.js                the whole client UI
lib/
  rules.js               bid increments + anti-snipe (shared by client & server)
  store.js               group storage with atomic bidding
  redis.js               Upstash connection
```

---

## Deploy it for free (about 10 minutes)

You need a free **GitHub** account and a free **Vercel** account. Both sign-ups
take a minute. Vercel's free **Hobby** plan covers this (personal, non-commercial
use — fine for a friends' auction).

### Step 1 — Put the code on GitHub
1. Create a new empty repository at https://github.com/new (e.g. `paddle`).
2. Upload this whole folder to it. Easiest on the website: open the repo →
   **Add file → Upload files** → drag everything in this folder in → **Commit**.
   (Don't upload `node_modules` or `.next` if present — they're not needed and
   are already in `.gitignore`.)

### Step 2 — Import into Vercel
1. Go to https://vercel.com/new and pick **Import Git Repository**.
2. Select your `paddle` repo. Vercel auto-detects Next.js — leave all settings as-is.
3. Click **Deploy**. The first build will succeed but the app will show a
   "Redis is not configured" message until you do Step 3. That's expected.

### Step 3 — Add the free database (Upstash Redis)
1. In your new project on Vercel, open the **Storage** tab.
2. **Create / Connect Database → Upstash → Redis**. Choose the **Free** plan,
   pick a region near you, and connect it to this project.
3. Vercel automatically adds the credentials (`KV_REST_API_URL` and
   `KV_REST_API_TOKEN`) as environment variables. You don't copy anything by hand.

### Step 4 — Redeploy
Environment variables only take effect on a fresh build. Go to the **Deployments**
tab → open the latest deployment → **⋯ → Redeploy**.

Done. Open your `https://your-app.vercel.app` URL, set your name, create a group,
and hit the share button (⤴) to copy the invite link for friends.

---

## Prefer the command line?

```bash
npm i -g vercel
cd paddle-vercel
vercel                      # links/creates the project and deploys a preview
vercel install              # add the Upstash Redis storage integration, then choose Redis/Free
vercel --prod               # deploy to production
```

`vercel install` provisions Upstash and pulls the env vars for you. Redeploy after.

---

## Run it on your own computer first (optional)

```bash
npm install
# create .env.local with your Upstash creds (see .env.example)
npm run dev
# open http://localhost:3000
```

You can get free Upstash credentials at https://console.upstash.com (create a
Redis database, copy the REST URL + token into `.env.local`).

---

## The shareable link

- The **invite link** is your deployed URL plus `?join=GROUPID`, e.g.
  `https://your-app.vercel.app/?join=ABC123`. Tapping it drops friends straight
  into the group (it'll ask for the password if the group has one).
- The share button also gives a plain **Group ID** and a `PADDLE:ID` code to paste
  into the "Join" screen — handy for messaging apps that mangle links.

---

## Good to know

- **Free tier limits.** Vercel Hobby gives 1,000,000 function calls and 100 GB
  bandwidth per month — far more than a friends' auction uses. Upstash free gives
  256 MB and 500,000 commands/month. The app polls for live updates only while a
  group is open and the tab is visible (every ~5s with a live auction, ~15s
  otherwise), which keeps usage low. If a very active group ever nears the Upstash
  limit, raise the poll interval in `app/page.js` (`desiredPoll`) or switch Upstash
  to pay-as-you-go ($0.20 per 100k commands).
- **No accounts / light security.** This is built for friends. There's no login;
  identity is just a display name stored on each person's device. Group passwords
  are basic gatekeeping, not real security — don't put anything sensitive in here.
- **Commercial use.** Vercel's Hobby plan is for personal, non-commercial projects.
  If you ever charge for this or run ads, you'd need Vercel Pro ($20/mo).
- **Testing the timer.** When posting a player you can choose a short auction
  length (down to 6 min) so you can watch the unsold/sold resolution and the
  5-minute anti-snipe extension without waiting a full day.
```
