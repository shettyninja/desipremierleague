import { NextResponse } from 'next/server';
import { searchGroups, createGroup } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

function fail(e) {
  if (e && e.code === 'NO_REDIS') {
    return NextResponse.json({ error: e.message }, { status: 503 });
  }
  console.error(e);
  return NextResponse.json({ error: 'Something went wrong.' }, { status: 500 });
}

export async function GET(req) {
  try {
    const q = req.nextUrl.searchParams.get('q') || '';
    const results = await searchGroups(q);
    return NextResponse.json(results, { headers: { 'cache-control': 'no-store' } });
  } catch (e) { return fail(e); }
}

export async function POST(req) {
  try {
    const body = await req.json();
    const name = (body.name || '').trim();
    const me = body.me;
    if (!name) return NextResponse.json({ error: 'Group name is required.' }, { status: 400 });
    if (!me || !me.id || !me.name) return NextResponse.json({ error: 'Set your name first.' }, { status: 400 });
    const group = await createGroup({ name, pass: body.pass || '', me });
    return NextResponse.json({ group });
  } catch (e) { return fail(e); }
}
