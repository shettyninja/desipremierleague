import { NextResponse } from 'next/server';
import { getGroup } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req, { params }) {
  try {
    const { id } = await params;
    const group = await getGroup(id);
    if (!group) return NextResponse.json({ error: 'Group not found.' }, { status: 404 });
    return NextResponse.json(group, { headers: { 'cache-control': 'no-store' } });
  } catch (e) {
    if (e && e.code === 'NO_REDIS') return NextResponse.json({ error: e.message }, { status: 503 });
    console.error(e);
    return NextResponse.json({ error: 'Something went wrong.' }, { status: 500 });
  }
}
