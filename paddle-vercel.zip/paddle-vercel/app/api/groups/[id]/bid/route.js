import { NextResponse } from 'next/server';
import { placeBid } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req, { params }) {
  try {
    const { id } = await params;
    const body = await req.json();
    if (!body.me || !body.me.id || !body.me.name) return NextResponse.json({ error: 'Set your name first.' }, { status: 400 });
    if (!body.playerId) return NextResponse.json({ error: 'Missing player.' }, { status: 400 });
    const res = await placeBid({ id, me: body.me, playerId: body.playerId, amount: body.amount });
    if (res.error) return NextResponse.json({ error: res.error }, { status: 400 });
    return NextResponse.json({ group: res.group, extended: !!res.extended });
  } catch (e) {
    if (e && e.code === 'NO_REDIS') return NextResponse.json({ error: e.message }, { status: 503 });
    console.error(e);
    return NextResponse.json({ error: 'Something went wrong.' }, { status: 500 });
  }
}
