import { NextResponse } from 'next/server';
import { postPlayer } from '@/lib/store';
import { DAY } from '@/lib/rules';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req, { params }) {
  try {
    const { id } = await params;
    const body = await req.json();
    const name = (body.name || '').trim();
    const basePrice = Number(body.basePrice);
    let durationMs = Number(body.durationMs);
    if (!body.me || !body.me.id || !body.me.name) return NextResponse.json({ error: 'Set your name first.' }, { status: 400 });
    if (!name) return NextResponse.json({ error: 'Player name is required.' }, { status: 400 });
    if (!Number.isFinite(basePrice) || basePrice <= 0) return NextResponse.json({ error: 'Enter a valid base price.' }, { status: 400 });
    if (!Number.isFinite(durationMs) || durationMs < 60000 || durationMs > DAY) durationMs = DAY;
    const res = await postPlayer({ id, me: body.me, name, basePrice, durationMs });
    if (res.error) return NextResponse.json({ error: res.error }, { status: 400 });
    return NextResponse.json({ group: res.group });
  } catch (e) {
    if (e && e.code === 'NO_REDIS') return NextResponse.json({ error: e.message }, { status: 503 });
    console.error(e);
    return NextResponse.json({ error: 'Something went wrong.' }, { status: 500 });
  }
}
