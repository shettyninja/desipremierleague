'use client';

import { useEffect, useRef } from 'react';
import {
  DAY, SNIPE, stepFor, minNextBid,
} from '@/lib/rules';

export default function Page() {
  const started = useRef(false);
  useEffect(() => {
    if (started.current) return; // guard React strict-mode double invoke
    started.current = true;
    runApp();
  }, []);

  return (
    <>
      <div className="app" id="app" />
      <div className="sheet-bg" id="sheetBg"><div className="sheet" id="sheet" /></div>
      <div className="toast" id="toast" />
    </>
  );
}

/* ============================================================================
   Everything below is the imperative app, mounted once into #app.
   ========================================================================== */
function runApp() {
  const AVATAR_COLORS = ['#F2B53C','#39D98A','#5AA9FF','#FB6F70','#C39BFF','#FF9F45','#54D6C9','#FF7AB6'];
  const colorFor = (seed) => { let h=0; for (const c of (seed||'?')) h=(h*31+c.charCodeAt(0))>>>0; return AVATAR_COLORS[h%AVATAR_COLORS.length]; };
  const initials = (name) => { const p=(name||'?').trim().split(/\s+/); return ((p[0]||'?')[0]+(p[1]?p[1][0]:'')).toUpperCase(); };
  const uid = () => 'u_'+Math.random().toString(36).slice(2,12);

  const fmt = (n) => Number(n).toLocaleString('en-IN');
  function fmtClock(ms){ if(ms<=0) return '0:00'; const s=Math.floor(ms/1000),h=Math.floor(s/3600),m=Math.floor((s%3600)/60),ss=s%60,pad=x=>String(x).padStart(2,'0'); return h>0?`${h}:${pad(m)}:${pad(ss)}`:`${m}:${pad(ss)}`; }
  function fmtAgo(t){ const d=Date.now()-t,m=Math.floor(d/60000); if(m<1)return 'just now'; if(m<60)return m+'m ago'; const h=Math.floor(m/60); if(h<24)return h+'h ago'; return Math.floor(h/24)+'d ago'; }
  function fmtWhen(t){ return new Date(t).toLocaleString([], {month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}); }

  // client mirror of expiry resolution, for instant display before the server confirms
  function resolveExpired(g){ const now=Date.now(); for(const p of g.players){ if(p.status==='active'&&now>=p.expiresAt){ p.status=p.currentBidderId?'sold':'unsold'; p.soldAt=now; } } }

  /* ---------- identity + my-groups (local) ---------- */
  function loadMe(){ try{ const m=JSON.parse(localStorage.getItem('paddle:me')); if(m&&m.id) return m; }catch{} const me={id:uid(),name:''}; localStorage.setItem('paddle:me',JSON.stringify(me)); return me; }
  function saveMe(){ localStorage.setItem('paddle:me',JSON.stringify(App.me)); }
  function myGroupIds(){ try{ return JSON.parse(localStorage.getItem('paddle:mygroups'))||[]; }catch{ return []; } }
  function addMyGroup(id){ const ids=myGroupIds(); if(!ids.includes(id)){ ids.unshift(id); localStorage.setItem('paddle:mygroups',JSON.stringify(ids)); } }

  /* ---------- API ---------- */
  async function jpost(url, body){
    try{
      const r=await fetch(url,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});
      const d=await r.json().catch(()=>({error:'Unexpected response.'}));
      return d;
    }catch{ return {error:'Network error — check your connection.'}; }
  }
  const api = {
    async search(q){ try{ const r=await fetch('/api/groups?q='+encodeURIComponent(q),{cache:'no-store'}); return r.ok? r.json():[]; }catch{ return []; } },
    async create(name,pass){ return jpost('/api/groups',{name,pass,me:App.me}); },
    async get(id){ try{ const r=await fetch('/api/groups/'+id,{cache:'no-store'}); if(!r.ok) return null; return r.json(); }catch{ return null; } },
    async join(id,pass){ return jpost('/api/groups/'+id+'/join',{pass,me:App.me}); },
    async post(id,name,basePrice,durationMs){ return jpost('/api/groups/'+id+'/players',{me:App.me,name,basePrice,durationMs}); },
    async bid(id,playerId,amount){ return jpost('/api/groups/'+id+'/bid',{me:App.me,playerId,amount}); },
  };

  /* ---------- app state ---------- */
  const App = { me:loadMe(), route:{name:'home'}, groupTab:'live', group:null, search:'', el:document.getElementById('app') };

  /* ---------- helpers ---------- */
  const h = (html)=>{ const t=document.createElement('template'); t.innerHTML=html.trim(); return t.content.firstElementChild; };
  const esc = (s)=> String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const avatarHTML = (name,size=24)=> `<span class="avatar" style="width:${size}px;height:${size}px;font-size:${Math.round(size*0.42)}px;background:${colorFor(name)}">${esc(initials(name))}</span>`;

  function topbar({title,sub,back,showMe=true,share=false}){
    return `<div class="topbar">
      ${back?`<button class="back" data-act="back">‹</button>`:`<div class="brand"><div class="logo display">P</div></div>`}
      <div class="brand" style="flex-direction:column;align-items:flex-start"><h1>${esc(title)}</h1>${sub?`<div class="sub">${esc(sub)}</div>`:''}</div>
      <div class="spacer"></div>
      ${share?`<button class="back" data-act="invite" title="Invite people" style="font-size:16px">⤴</button>`:''}
      ${showMe?`<div class="whoami" data-act="settings">${avatarHTML(App.me.name||'You',24)}<span class="nm">${esc(App.me.name||'Set name')}</span></div>`:''}
    </div>`;
  }

  /* ---------- onboarding ---------- */
  function renderOnboarding(){
    App.el.innerHTML='';
    App.el.appendChild(h(`<div class="scroll" style="display:flex;flex-direction:column;justify-content:center;min-height:100dvh">
      <div style="text-align:center;margin-bottom:26px">
        <div class="logo display" style="width:64px;height:64px;border-radius:18px;font-size:34px;margin:0 auto 18px">P</div>
        <div class="eyebrow">Player auctions, with friends</div>
        <h1 class="display h-lg" style="font-size:32px">Welcome to Paddle</h1>
        <p class="lede">Spin up a tournament, post players, and let the bidding wars begin. First, what should everyone call you?</p>
      </div>
      <div class="field"><label>Your display name</label>
        <input class="input" id="onName" placeholder="e.g. Rohit" maxlength="24" autocomplete="off"></div>
      <button class="btn gold" id="onGo">Get started</button>
    </div>`));
    const inp=App.el.querySelector('#onName'); inp.value=App.me.name||''; inp.focus();
    const go=()=>{ const v=inp.value.trim(); if(!v) return toast('Enter a name to continue','err'); App.me.name=v; saveMe(); boot2(); };
    App.el.querySelector('#onGo').onclick=go; inp.onkeydown=e=>{ if(e.key==='Enter') go(); };
  }

  /* ---------- home ---------- */
  async function renderHome(){
    App.route={name:'home'}; stopLoops();
    const ids=myGroupIds(); const groups=[];
    for(const id of ids){ const g=await api.get(id); if(g) groups.push(g); }

    App.el.innerHTML='';
    App.el.appendChild(h(topbar({title:'Paddle', sub:'Player auctions'})));
    const scroll=h(`<div class="scroll"></div>`);

    scroll.appendChild(h(`<div class="card stack" style="background:linear-gradient(160deg,#1b2331,#141821);border-color:#26303f">
      <div><div class="eyebrow">Start something</div>
        <div class="display" style="font-size:21px;font-weight:800;margin-top:5px">Create or join a tournament</div></div>
      <button class="btn gold" data-act="create">+ Create a group</button>
      <button class="btn ghost" data-act="join">Join with link or ID</button>
    </div>`));

    scroll.appendChild(h(`<div style="margin-top:18px">
      <div class="section-head"><h2>Find a group</h2></div>
      <input class="input" id="searchInp" placeholder="Search groups by name…" value="${esc(App.search)}">
      <div id="searchResults"></div></div>`));

    const myWrap=h(`<div style="margin-top:22px"></div>`);
    myWrap.appendChild(h(`<div class="section-head"><h2>Your groups</h2><span class="count">${groups.length}</span></div>`));
    if(!groups.length){
      myWrap.appendChild(h(`<div class="empty"><div class="big">🪙</div>You haven't joined any groups yet.<br>Create one or join with a code to get bidding.</div>`));
    } else {
      const list=h(`<div class="stack"></div>`);
      for(const g of groups){ resolveExpired(g); const live=g.players.filter(p=>p.status==='active').length;
        list.appendChild(h(`<div class="card grow" data-open="${g.id}">
          <div class="gtoken" style="background:${colorFor(g.name)}">${esc(initials(g.name))}</div>
          <div style="flex:1;min-width:0"><div class="nm">${esc(g.name)}</div>
            <div class="meta">${g.members.length} member${g.members.length>1?'s':''} · ${live} live · ID ${esc(g.id)}</div></div>
          <div class="chev">›</div></div>`)); }
      myWrap.appendChild(list);
    }
    scroll.appendChild(myWrap);
    scroll.appendChild(h(`<div class="syncline"><span class="d"></span>Live — friends share these auctions through your deployed link</div>`));
    App.el.appendChild(scroll);
    wireHome(scroll);
  }

  function wireHome(scroll){
    scroll.querySelectorAll('[data-open]').forEach(el=> el.onclick=()=>openGroup(el.dataset.open));
    scroll.querySelector('[data-act="create"]').onclick=sheetCreateGroup;
    scroll.querySelector('[data-act="join"]').onclick=()=>sheetJoinGroup();
    App.el.querySelector('[data-act="settings"]').onclick=sheetSettings;

    const inp=scroll.querySelector('#searchInp'); const results=scroll.querySelector('#searchResults'); let t=null;
    const run=async()=>{
      App.search=inp.value; const q=inp.value.trim(); results.innerHTML='';
      if(!q) return;
      const hits=await api.search(q);
      if(!hits.length){ results.appendChild(h(`<div class="empty" style="margin-top:12px;padding:20px">No groups match “${esc(q)}”.</div>`)); return; }
      const list=h(`<div class="stack" style="margin-top:12px"></div>`); const mine=myGroupIds();
      for(const x of hits){ const joined=mine.includes(x.id);
        list.appendChild(h(`<div class="card grow">
          <div class="gtoken" style="background:${colorFor(x.name)}">${esc(initials(x.name))}</div>
          <div style="flex:1;min-width:0"><div class="nm">${esc(x.name)}</div>
            <div class="meta">ID ${esc(x.id)} · ${x.hasPass?'🔒 password':'open'}</div></div>
          <button class="btn sm ${joined?'ghost':'gold'}" data-jid="${x.id}" data-pass="${x.hasPass?1:0}">${joined?'Open':'Join'}</button></div>`)); }
      results.appendChild(list);
      results.querySelectorAll('[data-jid]').forEach(b=>{ b.onclick=async()=>{
        const id=b.dataset.jid, needPass=b.dataset.pass==='1';
        if(myGroupIds().includes(id)) return openGroup(id);
        if(needPass){ sheetJoinGroup(id); }
        else { const r=await api.join(id,''); if(r.error) toast(r.error,'err'); else { addMyGroup(id); toast('Joined '+r.group.name,'ok'); openGroup(id); } }
      }; });
    };
    inp.oninput=()=>{ clearTimeout(t); t=setTimeout(run,220); };
    if(App.search) run();
  }

  /* ---------- loops (live polling) ---------- */
  let tickHandle=null, pollHandle=null, pollMs=5000;
  function sig(o){ return o.players.map(p=>p.id+p.status+(p.currentBid||0)+p.bids.length+p.expiresAt).join('|')+'#'+o.members.length; }
  function desiredPoll(){ const live=App.group?App.group.players.some(p=>p.status==='active'):false; return live?5000:15000; }
  function startLoops(){
    stopLoops();
    tickHandle=setInterval(()=>{ if(App.route.name==='group') refreshLiveDOM(); },1000);
    schedulePoll();
    document.addEventListener('visibilitychange', onVis);
  }
  function schedulePoll(){
    clearTimeout(pollHandle); pollMs=desiredPoll();
    pollHandle=setTimeout(async function loop(){
      if(App.route.name==='group' && document.visibilityState==='visible'){
        const fresh=await api.get(App.group.id);
        if(fresh){ if(sig(fresh)!==sig(App.group)){ App.group=fresh; renderGroup(); if(sheetOpenFor&&sheetOpenFor.type==='player') refreshOpenPlayerSheet(); } else { App.group=fresh; } }
      }
      pollMs=desiredPoll(); pollHandle=setTimeout(loop, pollMs);
    }, pollMs);
  }
  function onVis(){ if(document.visibilityState==='visible' && App.route.name==='group'){ clearTimeout(pollHandle); schedulePoll(); } }
  function stopLoops(){ clearInterval(tickHandle); clearTimeout(pollHandle); tickHandle=pollHandle=null; document.removeEventListener('visibilitychange', onVis); }

  async function openGroup(id){
    const g=await api.get(id);
    if(!g){ toast('Group not found','err'); return renderHome(); }
    addMyGroup(id);
    App.group=g; App.route={name:'group',id}; App.groupTab='live';
    renderGroup(); startLoops();
  }

  /* ---------- group view ---------- */
  function renderGroup(){
    const g=App.group; resolveExpired(g);
    App.el.innerHTML='';
    App.el.appendChild(h(topbar({title:g.name, sub:`${g.members.length} members · ID ${g.id}`, back:true, share:true})));
    const scroll=h(`<div class="scroll has-nav"></div>`);

    if(App.groupTab==='live'){
      const active=g.players.filter(p=>p.status==='active').sort((a,b)=>a.expiresAt-b.expiresAt);
      scroll.appendChild(h(`<div class="section-head"><h2>Live auctions</h2><span class="count">${active.length} open</span></div>`));
      if(!active.length){
        scroll.appendChild(h(`<div class="empty"><div class="big">🏏</div>No players on the block right now.<br>Tap <b style="color:var(--gold)">+</b> to post a player and set a base price.</div>`));
      } else { const list=h(`<div class="stack"></div>`); for(const p of active) list.appendChild(playerCard(p)); scroll.appendChild(list); }
      scroll.appendChild(h(`<div class="note" style="margin-top:20px">Auctions run for the time the poster picks (default 24h). Any bid in the final 5 minutes pushes the close out by 5 more minutes — no last-second snipes.</div>`));
    } else {
      const done=g.players.filter(p=>p.status!=='active').sort((a,b)=>(b.soldAt||0)-(a.soldAt||0));
      const sold=done.filter(p=>p.status==='sold').length;
      scroll.appendChild(h(`<div class="section-head"><h2>Group history</h2><span class="count">${sold} sold · ${done.length-sold} unsold</span></div>`));
      if(!done.length){ scroll.appendChild(h(`<div class="empty"><div class="big">📜</div>Nothing has closed yet.<br>Finished auctions — sold and unsold — land here.</div>`)); }
      else { const list=h(`<div class="stack"></div>`); for(const p of done) list.appendChild(historyCard(p)); scroll.appendChild(list); }
    }
    App.el.appendChild(scroll);

    App.el.appendChild(h(`<div class="botnav">
      <button class="navtab ${App.groupTab==='live'?'active':''}" data-tab="live"><span class="ic">⚡</span>Live</button>
      <button class="fab" data-act="post">+</button>
      <button class="navtab ${App.groupTab==='history'?'active':''}" data-tab="history"><span class="ic">📜</span>History</button>
    </div>`));

    App.el.querySelector('[data-act="back"]')?.addEventListener('click', ()=>{ stopLoops(); renderHome(); });
    App.el.querySelector('[data-act="invite"]')?.addEventListener('click', sheetInvite);
    App.el.querySelector('[data-act="settings"]')?.addEventListener('click', sheetSettings);
    App.el.querySelectorAll('[data-tab]').forEach(b=> b.onclick=()=>{ App.groupTab=b.dataset.tab; renderGroup(); });
    App.el.querySelector('[data-act="post"]').onclick=sheetPostPlayer;
    scroll.querySelectorAll('[data-player]').forEach(el=> el.onclick=()=> sheetPlayer(el.dataset.player));
  }

  function playerCard(p){
    const remaining=p.expiresAt-Date.now(), soon=remaining<=SNIPE;
    const priceLabel=p.currentBid==null?'Base price':'Top bid', priceVal=p.currentBid==null?p.basePrice:p.currentBid;
    return h(`<div class="card pcard" data-player="${p.id}" data-exp="${p.expiresAt}" data-live="1">
      <div class="row1"><div style="min-width:0"><div class="pname">${esc(p.name)}</div>
        <div class="pby">posted by ${esc(p.postedByName)} · ${fmtAgo(p.postedAt)}</div></div>
        <div class="price-block"><div class="price-label">${priceLabel}</div><div class="price-val">${fmt(priceVal)}</div>
          ${p.currentBid!=null?`<div class="leader">by <b>${esc(p.currentBidderName)}</b></div>`:''}</div></div>
      ${p.extended?`<div class="extstrip">⏱ Extended — last-minute bid added 5 min</div>`:''}
      <div class="pfoot"><div class="timer ${soon?'soon':''}" data-timer><span class="dot"></span><span class="t">${fmtClock(remaining)}</span>${soon?'<span style="font-weight:600">left</span>':''}</div>
        <div class="nbids">${p.bids.length} bid${p.bids.length===1?'':'s'}</div></div></div>`);
  }
  function historyCard(p){
    const badge=p.status==='sold'?`<span class="badge sold">● Sold</span>`:`<span class="badge unsold">● Unsold</span>`;
    const right=p.status==='sold'
      ? `<div class="price-block"><div class="price-label">Sold for</div><div class="price-val small" style="color:var(--green)">${fmt(p.currentBid)}</div><div class="leader">to <b>${esc(p.currentBidderName)}</b></div></div>`
      : `<div class="price-block"><div class="price-label">Base was</div><div class="price-val small" style="color:var(--coral)">${fmt(p.basePrice)}</div></div>`;
    return h(`<div class="card pcard" data-player="${p.id}"><div class="row1">
      <div style="min-width:0"><div class="pname">${esc(p.name)}</div>
        <div class="pby">${badge} · ${p.bids.length} bid${p.bids.length===1?'':'s'} · closed ${fmtAgo(p.soldAt||p.expiresAt)}</div></div>
      ${right}</div></div>`);
  }

  function refreshLiveDOM(){
    let needsFull=false;
    App.el.querySelectorAll('[data-live="1"]').forEach(card=>{
      const exp=Number(card.dataset.exp), remaining=exp-Date.now();
      if(remaining<=0){ needsFull=true; return; }
      const timer=card.querySelector('[data-timer]');
      if(timer){ timer.querySelector('.t').textContent=fmtClock(remaining); timer.classList.toggle('soon', remaining<=SNIPE); }
    });
    if(needsFull){ (async()=>{ const fresh=await api.get(App.group.id); if(fresh){ App.group=fresh; renderGroup(); } })(); }
    if(sheetOpenFor&&sheetOpenFor.type==='player'){ const t=document.querySelector('#sheetTimer'); if(t){ const p=App.group.players.find(x=>x.id===sheetOpenFor.id); if(p){ const r=p.expiresAt-Date.now(); t.textContent=p.status==='active'?fmtClock(Math.max(0,r)):'closed'; } } }
  }

  /* ---------- sheets ---------- */
  let sheetOpenFor=null;
  const sheetBg=document.getElementById('sheetBg'), sheetEl=document.getElementById('sheet');
  function openSheet(inner,ctx){ sheetEl.innerHTML=`<div class="grip"></div>`+inner; sheetOpenFor=ctx||{type:'generic'}; sheetBg.classList.add('open'); }
  function closeSheet(){ sheetBg.classList.remove('open'); sheetOpenFor=null; }
  sheetBg.addEventListener('click',e=>{ if(e.target===sheetBg) closeSheet(); });

  function sheetSettings(){
    openSheet(`<h3>Your profile</h3><p class="sub">This name shows on the players you post and the bids you place.</p>
      <div class="field"><label>Display name</label><input class="input" id="stName" value="${esc(App.me.name)}" maxlength="24"></div>
      <button class="btn gold" id="stSave">Save</button>`);
    sheetEl.querySelector('#stSave').onclick=()=>{ const v=sheetEl.querySelector('#stName').value.trim(); if(!v) return toast("Name can't be empty",'err'); App.me.name=v; saveMe(); closeSheet(); toast('Saved','ok'); if(App.route.name==='group') renderGroup(); else renderHome(); };
  }

  function sheetCreateGroup(){
    openSheet(`<h3>Create a group</h3><p class="sub">Give your tournament a name people can find. Add a password if you want it invite-only.</p>
      <div class="field"><label>Group / tournament name</label><input class="input" id="cgName" placeholder="e.g. Sunday Street League" maxlength="40"></div>
      <div class="field"><label>Password <span style="color:var(--faint);font-weight:400">(optional)</span></label><input class="input" id="cgPass" placeholder="Leave blank for an open group" maxlength="24"></div>
      <button class="btn gold" id="cgGo">Create group</button>`);
    sheetEl.querySelector('#cgGo').onclick=async()=>{ const name=sheetEl.querySelector('#cgName').value.trim(); if(!name) return toast('Name your group first','err'); const pass=sheetEl.querySelector('#cgPass').value;
      const r=await api.create(name,pass); if(r.error) return toast(r.error,'err'); addMyGroup(r.group.id); closeSheet(); await openGroup(r.group.id); setTimeout(sheetInvite,300); };
    setTimeout(()=>sheetEl.querySelector('#cgName').focus(),250);
  }

  function sheetJoinGroup(prefillId){
    openSheet(`<h3>Join a group</h3><p class="sub">Paste an invite link, or type the group ID and password the admin shared.</p>
      <div class="field"><label>Invite link or ID</label><input class="input" id="jgId" placeholder="ABC123 or a paddle link" value="${esc(prefillId||'')}" autocapitalize="characters"></div>
      <div class="field"><label>Password <span style="color:var(--faint);font-weight:400">(if any)</span></label><input class="input" id="jgPass" placeholder="Group password"></div>
      <button class="btn gold" id="jgGo">Join</button>`);
    sheetEl.querySelector('#jgGo').onclick=async()=>{ const raw=sheetEl.querySelector('#jgId').value; const parsed=parseLink(raw); const id=parsed?parsed.id:raw.trim(); const pass=sheetEl.querySelector('#jgPass').value||(parsed?parsed.pass:''); if(!id) return toast('Enter a link or ID','err');
      const r=await api.join(id,pass); if(r.error) return toast(r.error,'err'); addMyGroup(r.group.id); closeSheet(); toast('Joined '+r.group.name,'ok'); openGroup(r.group.id); };
    setTimeout(()=>sheetEl.querySelector('#jgId').focus(),250);
  }

  function makeLink(g){ const base=(location.origin&&location.origin!=='null')?location.origin+location.pathname.replace(/\/$/,''):''; return { url: base?`${base}/?join=${g.id}`:`?join=${g.id}`, code:`PADDLE:${g.id}${g.pass?':'+g.pass:''}` }; }
  function parseLink(text){ text=(text||'').trim(); let m=text.match(/[?&]join=([A-Za-z0-9]+)(?:&p=([^&\s]*))?/i); if(m) return {id:m[1].toUpperCase(),pass:decodeURIComponent(m[2]||'')}; m=text.match(/PADDLE:([A-Za-z0-9]+):?([^\s]*)/i); if(m) return {id:m[1].toUpperCase(),pass:m[2]||''}; m=text.match(/^[A-Za-z0-9]{4,8}$/); if(m) return {id:text.toUpperCase(),pass:''}; return null; }

  function sheetInvite(){
    const g=App.group, link=makeLink(g);
    openSheet(`<h3>Invite people</h3><p class="sub">Share any of these so friends can join “${esc(g.name)}”.</p>
      <div class="field"><label>Invite link</label><div class="copybox"><code>${esc(link.url)}</code><button data-copy="${esc(link.url)}">Copy</button></div></div>
      <div class="field"><label>Group ID</label><div class="copybox"><code>${esc(g.id)}</code><button data-copy="${esc(g.id)}">Copy</button></div></div>
      ${g.pass?`<div class="field"><label>Password</label><div class="copybox"><code>${esc(g.pass)}</code><button data-copy="${esc(g.pass)}">Copy</button></div></div>`:''}
      <button class="btn ghost" id="invShare">Share…</button>`, {type:'invite'});
    sheetEl.querySelectorAll('[data-copy]').forEach(b=> b.onclick=()=>copyText(b.dataset.copy));
    sheetEl.querySelector('#invShare').onclick=async()=>{ const text=`Join my Paddle auction “${g.name}”.\n${link.url}${g.pass?`\nPassword: ${g.pass}`:''}`; if(navigator.share){ try{ await navigator.share({title:'Paddle invite',text}); }catch{} } else copyText(text); };
  }

  const DURATIONS=[{label:'24 hours',ms:DAY},{label:'2 hours',ms:2*60*60*1000},{label:'30 min',ms:30*60*1000},{label:'10 min',ms:10*60*1000},{label:'6 min · test snipe',ms:6*60*1000}];
  function sheetPostPlayer(){
    let durMs=DAY;
    openSheet(`<h3>Post a player</h3><p class="sub">Set a base price. Bidding opens immediately and anyone in the group can bid.</p>
      <div class="field"><label>Player name</label><input class="input" id="ppName" placeholder="e.g. Virat K." maxlength="40"></div>
      <div class="field"><label>Base price</label><input class="input mono" id="ppBase" inputmode="numeric" placeholder="e.g. 20"></div>
      <div class="field"><label>Auction length</label><div class="chips" id="ppChips">${DURATIONS.map((d,i)=>`<button class="chip ${i===0?'on':''}" data-ms="${d.ms}">${d.label}</button>`).join('')}</div></div>
      <button class="btn gold" id="ppGo" style="margin-top:6px">Put on the block</button>
      <div class="rulehint">Increments: under 50 → steps of 5 · 50–99 → steps of 10 · 100+ → steps of 20</div>`);
    const chips=sheetEl.querySelectorAll('#ppChips .chip');
    chips.forEach(c=> c.onclick=()=>{ chips.forEach(x=>x.classList.remove('on')); c.classList.add('on'); durMs=Number(c.dataset.ms); });
    sheetEl.querySelector('#ppGo').onclick=async()=>{ const name=sheetEl.querySelector('#ppName').value.trim(); const base=parseInt(sheetEl.querySelector('#ppBase').value,10);
      if(!name) return toast('Enter the player name','err'); if(!Number.isFinite(base)||base<=0) return toast('Enter a valid base price','err');
      const r=await api.post(App.group.id,name,base,durMs); if(r.error) return toast(r.error,'err'); App.group=r.group; closeSheet(); App.groupTab='live'; renderGroup(); toast('Player is live','ok'); };
    setTimeout(()=>sheetEl.querySelector('#ppName').focus(),250);
  }

  function sheetPlayer(playerId){ const p=App.group.players.find(x=>x.id===playerId); if(p) renderPlayerSheet(p); }
  function refreshOpenPlayerSheet(){ if(!sheetOpenFor||sheetOpenFor.type!=='player') return; const p=App.group.players.find(x=>x.id===sheetOpenFor.id); if(p) renderPlayerSheet(p,true); }

  function renderPlayerSheet(p){
    const active=p.status==='active'&&Date.now()<p.expiresAt;
    const remaining=p.expiresAt-Date.now(), min=minNextBid(p);
    const statusBadge=p.status==='active'?`<span class="badge live">● Live</span>`:p.status==='sold'?`<span class="badge sold">● Sold</span>`:`<span class="badge unsold">● Unsold</span>`;
    const bidsHTML=p.bids.length
      ? [...p.bids].reverse().map((b,i)=>{ const won=(p.status==='sold'&&b.bidderId===p.currentBidderId&&b.amount===p.currentBid&&i===0);
          return `<div class="bidrow ${won?'win':''}">${avatarHTML(b.bidderName,30)}<div><div class="who">${esc(b.bidderName)} ${won?'<span class="crown">👑</span>':''}</div><div class="tm">${fmtWhen(b.at)}</div></div><div class="amt">${fmt(b.amount)}</div></div>`; }).join('')
      : `<div class="empty" style="padding:22px">No bids yet. ${active?'Be the first.':'This went unsold.'}</div>`;
    const biddingUI=active?`<div id="bidUI" style="margin-top:8px">
        <div class="stepper"><button id="bidMinus">−</button><div class="bidamt"><div class="v mono" id="bidVal">${fmt(min)}</div><div class="k">your bid</div></div><button id="bidPlus">+</button></div>
        <div class="rulehint" id="bidHint">Minimum bid is ${fmt(min)} · steps of ${stepFor(p.currentBid==null?min:p.currentBid)} at this level</div>
        <button class="btn gold" id="bidGo">Place bid</button></div>`
      : `<div style="margin-top:10px">${p.status==='sold'
          ? `<div class="card" style="text-align:center;background:rgba(57,217,138,.07);border-color:rgba(57,217,138,.3)"><div class="price-label">Won by</div><div style="display:flex;align-items:center;justify-content:center;gap:8px;margin-top:8px">${avatarHTML(p.currentBidderName,28)}<b style="font-size:16px">${esc(p.currentBidderName)}</b></div><div class="price-val" style="color:var(--green);margin-top:6px">${fmt(p.currentBid)}</div></div>`
          : `<div class="card" style="text-align:center;background:rgba(251,111,112,.06);border-color:rgba(251,111,112,.3)"><div style="font-size:15px;font-weight:700;color:var(--coral)">Went unsold</div><div class="sub" style="margin:6px 0 0">No bids before the timer ran out.</div></div>`}</div>`;

    openSheet(`<div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px">
        <div><h3 style="margin-bottom:6px">${esc(p.name)}</h3><div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">${statusBadge}<span class="sub" style="margin:0">posted by ${esc(p.postedByName)}</span></div></div>
        ${active?`<div style="text-align:right"><div class="price-label">closes in</div><div class="mono" id="sheetTimer" style="font-size:18px;font-weight:700;color:${remaining<=SNIPE?'var(--coral)':'var(--text)'}">${fmtClock(Math.max(0,remaining))}</div></div>`:''}</div>
      ${p.extended?`<div class="extstrip" style="margin-top:10px">⏱ Timer was extended ${p.extendCount}× by last-minute bids</div>`:''}
      <div class="card" style="margin-top:14px;display:flex;justify-content:space-between;align-items:center">
        <div><div class="price-label">${p.currentBid==null?'Base price':'Current top bid'}</div><div class="price-val">${fmt(p.currentBid==null?p.basePrice:p.currentBid)}</div>${p.currentBid!=null?`<div class="leader">held by <b>${esc(p.currentBidderName)}</b></div>`:''}</div>
        <div style="text-align:right"><div class="price-label">Base</div><div class="mono" style="font-size:15px;color:var(--muted)">${fmt(p.basePrice)}</div></div></div>
      ${biddingUI}
      <hr class="sep"><div class="section-head" style="margin:0 2px 6px"><h2>Bid history</h2><span class="count">${p.bids.length}</span></div><div>${bidsHTML}</div>`,
      {type:'player', id:p.id});

    if(!active) return;
    let val=min; const valEl=sheetEl.querySelector('#bidVal'), minus=sheetEl.querySelector('#bidMinus'), plus=sheetEl.querySelector('#bidPlus');
    const setVal=v=>{ val=v; valEl.textContent=fmt(v); minus.disabled=(v<=min); };
    setVal(min);
    plus.onclick=()=> setVal(val+stepFor(val));
    minus.onclick=()=>{ const s=stepFor(val-1); setVal(Math.max(min, val-s)); };
    sheetEl.querySelector('#bidGo').onclick=async()=>{ const r=await api.bid(App.group.id, p.id, val);
      if(r.error){ toast(r.error,'err'); const fresh=await api.get(App.group.id); if(fresh){ App.group=fresh; renderGroup(); refreshOpenPlayerSheet(); } return; }
      App.group=r.group; toast(r.extended?'Bid in! Timer +5 min':'Bid placed','ok'); renderGroup(); refreshOpenPlayerSheet(); };
  }

  /* ---------- utilities ---------- */
  let toastTimer=null;
  function toast(msg,kind=''){ const t=document.getElementById('toast'); t.textContent=msg; t.className='toast '+kind; requestAnimationFrame(()=>t.classList.add('show')); clearTimeout(toastTimer); toastTimer=setTimeout(()=>t.classList.remove('show'),2600); }
  async function copyText(text){ try{ await navigator.clipboard.writeText(text); toast('Copied','ok'); }catch{ const ta=document.createElement('textarea'); ta.value=text; document.body.appendChild(ta); ta.select(); try{ document.execCommand('copy'); toast('Copied','ok'); }catch{ toast('Long-press to copy','err'); } ta.remove(); } }

  async function handleIncomingLink(){
    const u=new URL(location.href); let id=u.searchParams.get('join'), pass=u.searchParams.get('p')||'';
    if(!id) return false; id=id.toUpperCase();
    // clean the URL so a refresh doesn't re-trigger
    history.replaceState({}, '', location.pathname);
    const r=await api.join(id,pass);
    if(r.error){ sheetJoinGroup(id); renderHome(); return true; }
    addMyGroup(id); openGroup(id); return true;
  }

  /* ---------- boot ---------- */
  async function boot2(){ if(await handleIncomingLink()) return; renderHome(); }
  (async function boot(){ if(!App.me.name){ renderOnboarding(); return; } boot2(); })();
  window.addEventListener('beforeunload', stopLoops);
}
